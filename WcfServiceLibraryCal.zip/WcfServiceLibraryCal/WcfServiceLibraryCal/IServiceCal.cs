﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WcfServiceLibraryCal
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IServiceCal
    {
        ////[OperationContract]
        ////string GetData(int value);

        ////[OperationContract]
        ////CompositeType GetDataUsingDataContract(CompositeType composite);


        [OperationContract]
        //string Add(string n1, string n2);
        string Add(ContractTypes.calc cal);
        [OperationContract]

        string Subtract(ContractTypes.calc cal);

        [OperationContract]
        string Multiply(ContractTypes.calc cal);
        [OperationContract]

        string Divide(ContractTypes.calc cal);
        // TODO: Add your service operations here
    }

    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    // You can add XSD files into the project. After building the project, you can directly use the data types 
    //defined there, with the namespace "WcfServiceLibraryCal.ContractType".
    //[DataContract]
    //public class CompositeType
    //{
    //    bool boolValue = true;
    //    string stringValue = "Hello ";

    //    [DataMember]
    //    public bool BoolValue
    //    {
    //        get { return boolValue; }
    //        set { boolValue = value; }
    //    }

    //    [DataMember]
    //    public string StringValue
    //    {
    //        get { return stringValue; }
    //        set { stringValue = value; }
    //    }
    //}
}
