﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using WcfServiceLibraryCal.ContractTypes;

namespace WcfServiceLibraryCal
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
    public class CalService : IServiceCal
    {
        
        ////public string GetData(int value)
        ////{
        ////    return string.Format("You entered: {0}", value);
        ////}

        ////public CompositeType GetDataUsingDataContract(CompositeType composite)
        ////{
        ////    if (composite == null)
        ////    {
        ////        throw new ArgumentNullException("composite");
        ////    }
        ////    if (composite.BoolValue)
        ////    {
        ////        composite.StringValue += "Suffix";
        ////    }
        ////    return composite;
        ////}
        ///
        public string Add(ContractTypes.calc cal)//string n1, string n2)
        {
            try
            {
                if (cal != null)
                {
                    return (double.Parse(cal.input1) + double.Parse(cal.input2)).ToString();
                }
                return "0";
            }
            catch (Exception e)
            {
                return "Nan" + e.ToString();
            }
        }
        public string Subtract(ContractTypes.calc cal)
        {
            try
            {
                return (double.Parse(cal.input1) - double.Parse(cal.input2)).ToString();
            }
            catch { return "Nan"; }

        }
        public string Multiply(ContractTypes.calc cal)
        {
            try
            {
                return (double.Parse(cal.input1) * double.Parse(cal.input2)).ToString();
            }
            catch { return "Nan"; }
        }
        public string Divide(ContractTypes.calc cal)
        {
            try
            {
                return (double.Parse(cal.input1) / double.Parse(cal.input2)).ToString();
            }
            catch { return "Nan"; }
        }
    }
}
